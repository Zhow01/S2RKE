from .dinm_main import DINMHyperParams, apply_dinm_to_model, execute_dinm
