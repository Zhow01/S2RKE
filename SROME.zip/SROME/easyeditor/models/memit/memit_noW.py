
import os
from copy import deepcopy
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
import torch.nn as nn
import torch.optim as optim
from ..rome.layer_stats import layer_stats
from ...util import nethook
from ...util.generate import generate_fast
from ...util.globals import *
from .compute_z_subject import compute_z_subject
from .compute_ks import compute_ks
from .compute_z import compute_z, get_module_input_output_at_words, find_fact_lookup_idx
from .memit_hparams import MEMITHyperParams

# Cache variable(s)
CONTEXT_TEMPLATES_CACHE = None
COV_CACHE = {}
def update_param(model, name, new_value):
    for n, p in model.named_parameters():
        if n == name:
            with torch.no_grad():  # 使用 no_grad() 确保不会跟踪计算图
                p.copy_(new_value)  # 更新参数值
            return p
        
def update_matrix_W(K, Z, W_init=None, initial_lr=0.0001, num_iterations=20000, clip_value=0.1, momentum=0.9, reg_lambda=0.001):
    """
    使用梯度剪裁、正则化、动量梯度下降和学习率调整更新矩阵W。

    参数:
    K (torch tensor): 输入矩阵K，形状为 (1, 6400)。
    Z (torch tensor): 目标矩阵Z，形状为 (1600,)。
    W_init (torch tensor, optional): 初始矩阵W，形状为 (6400, 1600)。如果为None，则随机初始化。
    initial_lr (float): 初始学习率。
    num_iterations (int): 迭代次数。
    clip_value (float): 梯度剪裁的阈值。
    momentum (float): 动量系数。
    reg_lambda (float): 正则化系数。

    返回:
    torch tensor: 更新后的矩阵W，形状为 (6400, 1600)。
    """
    if W_init is None:
        W = torch.randn(6400, 1600, requires_grad=True)  # 随机初始化W
    else:
        W = W_init.clone().detach().requires_grad_(True)

    K = K.double()
    Z = Z.double()

    optimizer = optim.SGD([W], lr=initial_lr, momentum=momentum)
    scheduler = optim.lr_scheduler.ReduceLROnPlateau(optimizer, mode='min', factor=0.5, patience=1000, min_lr=1e-6)
    criterion = nn.MSELoss()

    for i in range(num_iterations):
        optimizer.zero_grad()

        KW = K @ W
        loss = criterion(KW.squeeze(), Z) + reg_lambda * torch.norm(W)**2
        loss.backward()

        # 梯度剪裁
        torch.nn.utils.clip_grad_norm_([W], clip_value)

        optimizer.step()
        scheduler.step(loss)

        # 每1000次迭代打印一次损失值
        if i % 1000 == 0:
            print(f"Iteration {i}, Loss: {loss.item()}, Learning Rate: {optimizer.param_groups[0]['lr']}")

    return W

def apply_memit_to_model(

    model: AutoModelForCausalLM,
    tok: AutoTokenizer,
    requests: List[Dict],
    hparams: MEMITHyperParams,
    copy=False,
    return_orig_weights=False,
    cache_template: Optional[str] = None,
    keep_original_weight=False,
    original=False,
    **kwargs
) -> Tuple[AutoModelForCausalLM, Dict[str, Any]]:
    """
    Returns a model with the desired changes.
    :param copy: If true, will preserve the original model while creating a new one to edit.
        Note that you are responsible for deallocating the new model's memory to avoid leaks.
    :return: (1) the updated model, (2) an original copy of the weights that changed
    """

    weights_copy = {}
    if copy:
        model = deepcopy(model)
    ##获取m和k的值，获取W参数矩阵
    zs,layer_stats = execute_memit(model, tok, requests, hparams, cache_template=cache_template)
    w_name = f"{hparams.rewrite_module_tmp.format(hparams.layers[0])}.weight"
    weights = nethook.get_parameter(
            model, w_name
        )
    
    w = weights.detach().clone()
    w.requires_grad_()
    weights_shape = w.shape
    #定义一个更新矩阵delta
    loss_function = nn.L1Loss()

    # 使用 Adam 优化器
    optimizer = optim.Adam([w], lr=1e-5)
    optimizer.zero_grad()
    # 梯度下降更新 W
    num_iterations = 1000
    for i in range(num_iterations):
        key_mat,m_mat = layer_stats,zs
        key_mat, m_mat = key_mat.to(f"cuda:{hparams.device}"), m_mat.to(f"cuda:{hparams.device}")
        loss = loss_function(m_mat,(key_mat.T@w))
        print(f"loss={loss.item()}")
        loss.backward()
        optimizer.step()
    update_param(model,w_name,new_value=w)
    if not keep_original_weight:
        weights_copy = {}

    return model, weights_copy


def execute_memit(
    model: AutoModelForCausalLM,
    tok: AutoTokenizer,
    requests: List[Dict],
    hparams: MEMITHyperParams,
    cache_template: Optional[str] = None,
) -> Dict[str, Tuple[torch.Tensor]]:
    """
    Executes the MEMIT update algorithm for the specified update at the specified layer
    Invariant: model at beginning of function == model at end of function
    """

    deltas = {}

    # Update target and print info
    requests = deepcopy(requests)
    for i, request in enumerate(requests):
        request["target_new"]["str"] = str(request["target_new"]["str"])
        if request["target_new"]["str"][0] != " ":
            # Space required for correct tokenization
            requests[i]["target_new"]['str'] = " " + request["target_new"]['str']

        if '{}' not in request['prompt']:
            assert request['subject'] in request['prompt'] or \
                   print(f"Subject:{request['subject']} do not exist in prompt: {request['prompt']}")

            requests[i]['prompt'] = requests[i]['prompt'].replace(requests[i]['subject'], '{}')

    for request in requests[:10]:
        print(
            f"MEMIT request sample: "
            f"[{request['prompt'].format(request['subject'])}] -> [{request['target_new']['str']}]"
        )

    # Retrieve weights that user desires to change


    # Compute z for final layer
    context_templates = get_context_templates(model, tok)
    z_layer = hparams.layers[-1]
    z_list = []

    for i,request in enumerate(requests):
        # Retrieve k/v pair if already stored in cache
        if (i<2):
            continue
        start = 2
        cache_fname = (
            Path(
                str(cache_template).format(
                    z_layer, hparams.clamp_norm_factor, request["case_rel_ids"]
                )
            )
            if cache_template is not None
            else None
        )
        data_loaded = False
        if (
            cache_fname is not None  # Require cache template
            and cache_fname.exists()  # Cache file must exist
        ):
            try:
                data = np.load(cache_fname)
                z_list.append(torch.from_numpy(data["v_star"]).to(f"cuda:{hparams.device}"))
                data_loaded = True
            except Exception as e:
                print(f"Error reading cache file due to {e}. Recomputing...")

        # Compute k/v pair if not loaded from cache
        if not data_loaded:
            cur_z = compute_z_subject(
                model,
                tok,
                all_request=requests,
                hparams=hparams,
                layer=z_layer,
                context_templates=context_templates,
            )
            z_list.append(cur_z)

            if cache_fname is not None:
                cache_fname.parent.mkdir(exist_ok=True, parents=True)
                np.savez(
                    cache_fname,
                    **{
                        "v_star": cur_z.detach().cpu().numpy(),
                    },
                )
                print(f"Cached k/v pair at {cache_fname}")
    
    zs = torch.stack(z_list, dim=1)
    

    # Get current model activations
    layer=17
    layer_ks = compute_ks(model, tok, requests[start:], hparams, layer, context_templates).T
    print(f"Writing {layer_ks.size(1)} key/value pair(s) into layer {layer}")

    return zs,layer_ks


def get_cov(
    model: AutoModelForCausalLM,
    tok: AutoTokenizer,
    layer_name: str,
    mom2_dataset: str,
    mom2_n_samples: str,
    mom2_dtype: str,
    inv: bool = False,
    force_recompute: bool = False,
    hparams=None,
) -> torch.Tensor:
    """
    Retrieves covariance statistics, then computes the algebraic inverse.
    Caches result for future use.
    """

    model_name = model.config._name_or_path.replace("/", "_")
    key = (model_name, layer_name)

    print(f"Retrieving covariance statistics for {model_name} @ {layer_name}.")
    if key not in COV_CACHE or force_recompute:
        stat = layer_stats(
            model,
            tok,
            layer_name,
            hparams.stats_dir,
            mom2_dataset,
            to_collect=["mom2"],
            sample_size=mom2_n_samples,
            precision=mom2_dtype,
            hparams=hparams,
            force_recompute=force_recompute,
        )
        COV_CACHE[key] = stat.mom2.moment().float().to("cpu")

    return (
        torch.inverse(COV_CACHE[key].to(f"cuda:{hparams.device}")) if inv else COV_CACHE[key].to(f"cuda:{hparams.device}")
    )


def upd_matrix_match_shape(matrix: torch.Tensor, shape: torch.Size) -> torch.Tensor:
    """
    GPT-2 and GPT-J have transposed weight representations.
    Returns a matrix that matches the desired shape, else raises a ValueError
    """

    if matrix.shape == shape:
        return matrix
    elif matrix.T.shape == shape:
        return matrix.T
    else:
        raise ValueError(
            "Update matrix computed by MEMIT does not match original weight shape. "
            "Check for bugs in the code?"
        )


def get_context_templates(model, tok):
    global CONTEXT_TEMPLATES_CACHE

    if CONTEXT_TEMPLATES_CACHE is None:
        CONTEXT_TEMPLATES_CACHE = [["{}"]] + [
            [
                f.replace("{", " ").replace("}", " ") + ". {}"
                for f in generate_fast(
                    model,
                    tok,
                    ["The", "Therefore", "Because", "I", "You"],
                    n_gen_per_prompt=n_gen // 5,
                    max_out_len=length,
                )
            ]
            for length, n_gen in [(10, 5)]  # Be careful about changing this.
        ]
        print(f"Cached context templates {CONTEXT_TEMPLATES_CACHE}")

    return CONTEXT_TEMPLATES_CACHE



