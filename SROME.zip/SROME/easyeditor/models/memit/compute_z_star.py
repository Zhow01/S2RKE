from typing import Dict, List, Tuple
import torch
import numpy as np
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from ..rome import repr_tools
from ...util import nethook

from .memit_hparams import MEMITHyperParams
lm_w, ln_f,lm_b = None, None,None
def data_prepare(request,tok,context_templates,hparams):
    # Tokenize target into list of int token IDs
    target_ids = tok(request["target_new"]["str"], return_tensors="pt").to(f"cuda:{hparams.device}")[
        "input_ids"
    ][0]

    if target_ids[0] == tok.bos_token_id or target_ids[0] == tok.unk_token_id:
        target_ids = target_ids[1:]
    # Compile list of rewriting and KL x/y pairs
    rewriting_prompts, kl_prompts = [
        context.format(request["prompt"]) + tok.decode(target_ids[:-1])
        for context_types in context_templates
        for context in context_types
    ], ["{} is a"]
    all_prompts = rewriting_prompts + kl_prompts

    input_tok = tok(
        [prompt.format(request["subject"]) for prompt in all_prompts],
        return_tensors="pt",
        padding=True,
    ).to(f"cuda:{hparams.device}")##填上subject，接着再token化

    # Compute rewriting targets
    rewriting_targets = torch.tensor(-100, device=f"cuda:{hparams.device}").repeat(
        len(rewriting_prompts), *input_tok["input_ids"].shape[1:]
    ) ## 6 x length(max(token))
    for i in range(len(rewriting_prompts)):
        ex_len = input_tok["attention_mask"][i].sum()
        rewriting_targets[i, ex_len - len(target_ids) : ex_len] = target_ids ##最后的预测token序列换上他们的token索引，其他的地方设置为-100，以方便后续计算loss
    ##for循环将rewritng_targets的对应位置替换为预测token的索引值
    # Compute indices of the tokens where the fact is looked up
    lookup_idxs = [
        find_fact_lookup_idx(
            prompt, request["subject"], tok, hparams.fact_token, verbose=(i == 0)
        )
        for i, prompt in enumerate(all_prompts)
    ]##找到每个prompt的subject的最后一个token的位置索引
    return lookup_idxs,kl_prompts,rewriting_prompts,rewriting_targets,target_ids,input_tok


def loss_prepare_pre(            
            model,
            input_tok,
            lookup_idxs,
            kl_prompts,
            kl_distr_init,
            hparams,
            loss_layer,
            rewriting_targets,
            rewriting_prompts,
            target_ids,
            target_init_tem,
            delta_tem,
            layer):
    def edit_output_fn(cur_out, cur_layer): ##这个函数的作用就是给hidden_state加上delta
        nonlocal target_init_tem
        if cur_layer == hparams.layer_module_tmp.format(layer):
            # Store initial value of the vector of interest
            if target_init_tem is None:
                print("Recording initial value of v*")
                # Initial value is recorded for the clean sentence
                target_init_tem = cur_out[0][0, lookup_idxs[0]].detach().clone()##初始化为第一个prompt(也就是输入的)的最后一个subject token输出的logits矩阵

            # Add intervened delta
            for i, idx in enumerate(lookup_idxs):

                if len(lookup_idxs)!=len(cur_out[0]):
                    cur_out[0][idx, i, :] += delta_tem##cur_out[0]的原因是取元祖的第一个矩阵对象
                else:
                    cur_out[0][i, idx, :] += delta_tem

        return cur_out
    with nethook.TraceDict(
        module=model,
        layers=[
            hparams.layer_module_tmp.format(loss_layer),
            hparams.layer_module_tmp.format(layer),
        ],
        retain_input=False,
        retain_output=True,
        edit_output=edit_output_fn,
        ) as tr:
            # Inserts new "delta" variable at the appropriate part of the computation

        logits = model(**input_tok).logits
                    # Compute distribution for KL divergence
        kl_logits = torch.stack(
            [
                logits[i - len(kl_prompts), idx, :]
                for i, idx in enumerate(lookup_idxs[-len(kl_prompts) :])
            ],
            dim=0,
        )##对于kl_prompt，取出其最后一个subject的最后一个token的预测logits矩阵
        kl_log_probs = torch.nn.functional.log_softmax(kl_logits, dim=1)#转化为概率
        if kl_distr_init is None:
            kl_distr_init = kl_log_probs.detach().clone()

        # Compute loss on rewriting targets
        output=tr[hparams.layer_module_tmp.format(loss_layer)].output[0]#取出来模型指定层的输出
        if output.shape[1]!=rewriting_targets.shape[1]:
            output=torch.transpose(output, 0, 1)
        full_repr = output[:len(rewriting_prompts)] #取出来原始prompt和+上前缀的prompt的预测output

        log_probs = torch.log_softmax(ln_f(full_repr) @ lm_w.to(full_repr.device) + lm_b.to(full_repr.device), dim=2)
        loss = torch.gather(
            log_probs,
            2,
            torch.where(rewriting_targets != -100, rewriting_targets, 0).unsqueeze(2).to(log_probs.device),
        ).squeeze(2)
        mask = (rewriting_targets != -100).float() ##计算哪些位置上的loss有效

        # Aggregate total losses
        nll_loss_each = -(loss * mask.to(loss.device)).sum(1) / target_ids.size(0)
        nll_loss = nll_loss_each.mean()
        kl_loss = hparams.kl_factor * torch.nn.functional.kl_div(
            kl_distr_init, kl_log_probs, log_target=True, reduction="batchmean"
        )

        weight_decay=0

        # weight_decay = hparams.v_weight_decay * torch.norm(delta) ** 2
        loss = nll_loss + kl_loss.to(nll_loss.device) 

    return loss,nll_loss

def loss_prepare_tem(
            model,
            input_tok,
            lookup_idxs,
            kl_prompts,
            kl_distr_init,
            hparams,
            loss_layer,
            rewriting_targets,
            rewriting_prompts,
            target_ids,
            target_init_tem,
            delta_tem,
            layer,
            is_init
              ):
    def edit_output_fn(cur_out, cur_layer): ##这个函数的作用就是给hidden_state加上delta
        nonlocal target_init_tem
        if cur_layer == hparams.layer_module_tmp.format(layer):
            # Store initial value of the vector of interest
            if target_init_tem is None:
                print("Recording initial value of v*")
                # Initial value is recorded for the clean sentence
                target_init_tem = cur_out[0][0, lookup_idxs[0]].detach().clone()##初始化为第一个prompt(也就是输入的)的最后一个subject token输出的logits矩阵

            # Add intervened delta
            for i, idx in enumerate(lookup_idxs):

                if len(lookup_idxs)!=len(cur_out[0]):
                    cur_out[0][idx, i, :] += delta_tem##cur_out[0]的原因是取元祖的第一个矩阵对象
                else:
                    cur_out[0][i, idx, :] += delta_tem

        return cur_out
    
    with nethook.TraceDict(
        module=model,
        layers=[
            hparams.layer_module_tmp.format(loss_layer),
            hparams.layer_module_tmp.format(layer),
        ],
        retain_input=False,
        retain_output=True,
        edit_output=edit_output_fn,
        ) as tr:
            # Inserts new "delta" variable at the appropriate part of the computation

        logits = model(**input_tok).logits
                    # Compute distribution for KL divergence
        kl_logits = torch.stack(
            [
                logits[i - len(kl_prompts), idx, :]
                for i, idx in enumerate(lookup_idxs[-len(kl_prompts) :])
            ],
            dim=0,
        )##对于kl_prompt，取出其最后一个subject的最后一个token的预测logits矩阵
        kl_log_probs = torch.nn.functional.log_softmax(kl_logits, dim=1)#转化为概率
        if kl_distr_init is None:
            kl_distr_init = kl_log_probs.detach().clone()

        # Compute loss on rewriting targets
        output=tr[hparams.layer_module_tmp.format(loss_layer)].output[0]#取出来模型指定层的输出
        if output.shape[1]!=rewriting_targets.shape[1]:
            output=torch.transpose(output, 0, 1)
        full_repr = output[:len(rewriting_prompts)] #取出来原始prompt和+上前缀的prompt的预测output

        log_probs = torch.log_softmax(ln_f(full_repr) @ lm_w.to(full_repr.device) + lm_b.to(full_repr.device), dim=2)
        loss = torch.gather(
            log_probs,
            2,
            torch.where(rewriting_targets != -100, rewriting_targets, 0).unsqueeze(2).to(log_probs.device),
        ).squeeze(2)
        mask = (rewriting_targets != -100).float() ##计算哪些位置上的loss有效

        # Aggregate total losses
        nll_loss_each = -(loss * mask.to(loss.device)).sum(1) / target_ids.size(0)
        nll_loss = nll_loss_each.mean()
        kl_loss = hparams.kl_factor * torch.nn.functional.kl_div(
            kl_distr_init, kl_log_probs, log_target=True, reduction="batchmean"
        )
        if (delta_tem is None):
            weight_decay=0
        else:
            weight_decay = hparams.v_weight_decay * (
                torch.norm(delta_tem) / torch.norm(target_init_tem) ** 2
            )
        # weight_decay = hparams.v_weight_decay * torch.norm(delta) ** 2
        loss = nll_loss + kl_loss.to(nll_loss.device) + weight_decay.to(nll_loss.device)
    if (is_init):
        return loss,nll_loss,target_init_tem
    else:
        return loss,nll_loss
def compute_z_star(
    model: AutoModelForCausalLM,
    tok: AutoTokenizer,
    all_request: List[Dict],
    hparams: MEMITHyperParams,
    layer: int,
    context_templates: List[str],
    beita=0.5
) -> Tuple[torch.Tensor, torch.Tensor]:
    """
    Computes the value (right) vector for the rank-1 update.
    Runs a simple optimization procedure.
    """
    global lm_w, ln_f, lm_b
    # Get model parameters
    lm_w, ln_f = (
        nethook.get_parameter(model, f"{hparams.lm_head_module}.weight").T,
        nethook.get_module(model, hparams.ln_f_module),
    )
    try:
        lm_b = nethook.get_parameter(model, f"{hparams.lm_head_module}.bias")
    except LookupError as _:
        lm_b = next(model.parameters()).new_zeros(model.config.vocab_size)

    print("Computing right vector (v)")
    pre_lookup_idxs=[]
    pre_kl_prompts=[]
    pre_rewriting_prompts=[]
    pre_rewriting_targets=[]
    pre_target_ids=[]
    pre_input_tok=[]
    lookup_idxs,kl_prompts,rewriting_prompts,rewriting_targets,target_ids,input_tok = data_prepare(
    request=request,tok=tok,context_templates=context_templates,hparams=hparams
            )
    for idx,tem_request in enumerate(all_request):
            if idx==tem_idx:
                break
            a,b,c,d,e,f = data_prepare(
                request=tem_request,tok=tok,context_templates=context_templates,hparams=hparams
            )
            pre_lookup_idxs.append(a)
            pre_kl_prompts.append(b)
            pre_rewriting_prompts.append(c)
            pre_rewriting_targets.append(d)
            pre_target_ids.append(e)
            pre_input_tok.append(f)

    # Finalize rewrite and loss layers
    loss_layer = max(hparams.v_loss_layer, layer)##找到拿logits矩阵的层
    print(f"Rewrite layer is {layer}")
    print(f"Tying optimization objective to {loss_layer}")

    # Set up an optimization over a latent vector that, when output at the
    # rewrite layer, i.e. hypothesized fact lookup location, will induce the
    # target token to be predicted at the final layer.
    if hasattr(model.config, 'n_embd'): ##这个delta居然就是一个1xhidden_size的矩阵
        delta = torch.zeros((model.config.n_embd,), requires_grad=True, device=f"cuda:{hparams.device}")
        delta_pre = torch.zeros((model.config.n_embd,), requires_grad=True, device=f"cuda:{hparams.device}")
    elif hasattr(model.config, 'hidden_size'):
        delta = torch.zeros((model.config.hidden_size,), requires_grad=True, device=f"cuda:{hparams.device}")
        delta_pre = torch.zeros((model.config.n_embd,), requires_grad=True, device=f"cuda:{hparams.device}")
    else:
        raise NotImplementedError
    target_init = None
    kl_distr_init,pre_kl_distr_init_list = None,[None for i in range(len(pre_kl_prompts))]



    # Optimizer
    opt = torch.optim.Adam([delta], lr=hparams.v_lr)
    nethook.set_requires_grad(False, model)

    # Execute optimization
    for it in range(hparams.v_num_grad_steps):
        opt.zero_grad()
        loss_pre_list=[]
        nll_loss_pre_list=[]
        # Forward propagation

        """
            model,
            input_tok,
            lookup_idxs,
            kl_prompts,
            kl_distr_init,
            hparams,
            loss_layer,
            rewriting_targets,
            rewriting_prompts,
            target_ids,
            kl_log_probs,
            delta,
            target_init,
            edit_func,
            layer
        """
        # Compute loss on rewriting targets
        if (it==0):

            loss_tem,nll_loss_tem,target_init = loss_prepare_tem(
                        model=model,
                        input_tok=input_tok,
                        lookup_idxs=lookup_idxs,
                        kl_prompts=kl_prompts,
                        kl_distr_init=kl_distr_init,
                        hparams=hparams,
                        loss_layer=loss_layer,
                        rewriting_targets=rewriting_targets,
                        rewriting_prompts=rewriting_prompts,
                        target_ids=target_ids,
                        target_init_tem=target_init,
                        delta_tem=delta,
                        layer=layer,
                        is_init=True
                                    )
        else:
            loss_tem,nll_loss_tem = loss_prepare_tem(
                                model=model,
                                input_tok=input_tok,
                                lookup_idxs=lookup_idxs,
                                kl_prompts=kl_prompts,
                                kl_distr_init=kl_distr_init,
                                hparams=hparams,
                                loss_layer=loss_layer,
                                rewriting_targets=rewriting_targets,
                                rewriting_prompts=rewriting_prompts,
                                target_ids=target_ids,
                                target_init_tem=target_init,
                                delta_tem=delta,
                                layer=layer,
                                is_init=False
                                            )
        for idx in range(len(pre_rewriting_prompts)):
            loss_pre,nll_loss_pre = loss_prepare_pre(
                    model=model,
                    input_tok=pre_input_tok[idx],
                    lookup_idxs=pre_lookup_idxs[idx],
                    kl_prompts=pre_kl_prompts[idx],
                    kl_distr_init=pre_kl_distr_init_list[idx],
                    hparams=hparams,
                    loss_layer=loss_layer,
                    rewriting_targets=pre_rewriting_targets[idx],
                    rewriting_prompts=pre_rewriting_prompts[idx],
                    target_ids=pre_target_ids[idx],
                    target_init_tem=target_init,
                    delta_tem=delta,
                    layer=layer
                                )
            loss_pre_list.append(loss_pre)
            nll_loss_pre_list.append(nll_loss_pre)
        if (tem_idx==0):
            loss = loss_tem

        else:
            loss_pre=loss_pre_list[0]
            for ls in loss_pre_list[1:]:
                loss_pre+=ls
            loss = (loss_tem+loss_pre).mean()
        
        if tem_idx==0:
            print(
                f"编辑第{tem_idx}重关系知识"
                f"loss {np.round(loss.item(), 3)} = loss_tem:{np.round(loss_tem.item(), 3)} "
                f"avg prob of [{request['target_new']}] "
                f"{torch.exp(-nll_loss_tem).mean().item()}"
                )
        else:
            print(
                f"编辑第{tem_idx}重关系知识"
                f"loss {np.round(loss.item(), 3)} = loss_tem:{np.round(loss_tem.item(), 3)} + loss_pre:{np.round(loss_pre.item(), 3)} "
                f"avg prob of [{request['target_new']}] "
                f"{torch.exp(-nll_loss_tem).mean().item()}"
                )
        
        for ldx in range(len(loss_pre_list)):
            print(
            f"之前的{ldx}重关系知识"
            f"loss = {np.round(loss_pre_list[ldx].item(), 3)}"
            f"avg prob of [{all_request[ldx]['target_new']}] "
            f"{torch.exp(-nll_loss_pre_list[ldx]).mean().item()}"
            )
        print( "****************************************PPSUC********************************************")
        
        if loss < 5e-2:
            break

        if it == hparams.v_num_grad_steps - 1:
            break

        # Backpropagate
        loss.backward()
        opt.step()

        # Project within L2 ball
        max_norm = hparams.clamp_norm_factor * target_init.norm()
        if delta.norm() > max_norm:
            with torch.no_grad():
                delta[...] = delta * max_norm / delta.norm()

    target = target_init + delta
    print(
        f"Init norm {target_init.norm()} | Delta norm {delta.norm()} | Target norm {target.norm()}"
    )

    return target


def get_module_input_output_at_words(
    model: AutoModelForCausalLM,
    tok: AutoTokenizer,
    layer: int,
    context_templates: List[str],
    words: List[str],
    module_template: str,
    fact_token_strategy: str,
    track=None,
) -> Tuple[torch.Tensor]:
    """
    Retrieves detached representations for a word at the input and
    output of a particular layer module.
    """

    word_repr_args = dict(
        model=model,
        tok=tok,
        layer=layer,
        module_template=module_template,
    )
    if "subject_" in fact_token_strategy and fact_token_strategy.index("subject_") == 0:
        context_info = dict(
            context_templates=context_templates,
            words=words,
        )
        subtoken = fact_token_strategy[len("subject_") :]
        if track == 'out' or track == 'in':
            return repr_tools.get_reprs_at_word_tokens(
                track=track, subtoken=subtoken, **context_info, **word_repr_args
            )
        l_input, l_output = repr_tools.get_reprs_at_word_tokens(
            track="both", subtoken=subtoken, **context_info, **word_repr_args
        )
    elif fact_token_strategy == "last":
        raise Exception("This is definitely bugged, fix it.")
        context_info = dict(
            contexts=[
                tmp[i].format(words[i]) for i, tmp in enumerate(context_templates)
            ],
            idxs=[000000],
        )
        if track == 'out' or track == 'in':
            return repr_tools.get_reprs_at_word_tokens(
                track=track, subtoken=subtoken, **context_info, **word_repr_args
            )
        l_input, l_output = repr_tools.get_reprs_at_idxs(
            track="both", **context_info, **word_repr_args
        )
    else:
        raise ValueError(f"fact_token={fact_token_strategy} not recognized")

    return l_input.detach(), l_output.detach()


def find_fact_lookup_idx(
    prompt: str,
    subject: str,
    tok: AutoTokenizer,
    fact_token_strategy: str,
    verbose=True,
) -> int:
    """
    Computes hypothesized fact lookup index given a sentence and subject.
    """

    ret = None
    if fact_token_strategy == "last":
        ret = -1
    elif (
        "subject_" in fact_token_strategy and fact_token_strategy.index("subject_") == 0
    ):
        ret = repr_tools.get_words_idxs_in_templates(
            tok=tok,
            context_templates=[prompt],
            words=[subject],
            subtoken=fact_token_strategy[len("subject_") :],
        )[0][0]
    else:
        raise ValueError(f"fact_token={fact_token_strategy} not recognized")

    sentence = prompt.format(subject)
    if verbose:
        print(
            f"Lookup index found: {ret} | Sentence: {sentence} | Token:",
            tok.decode(tok(sentence)["input_ids"][ret]),
        )

    return ret
