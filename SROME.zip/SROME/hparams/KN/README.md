alg_name: "KN"
model_name: "./hugging_cache/llama-2-7b"
device: 0

lr_scale: 1.0
n_toks: 10
refine: false
batch_size: 1
steps: 1
adaptive_threshold: 0.2
#threshold to collect
p: 0.4
#the threshold for the sharing percentage
