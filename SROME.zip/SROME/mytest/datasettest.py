from datasets import load_dataset
import subprocess
import os
import subprocess
import os

result = subprocess.run('bash -c "source /etc/network_turbo && env | grep proxy"', shell=True, capture_output=True, text=True)
output = result.stdout
for line in output.splitlines():
    if '=' in line:
        var, value = line.split('=', 1)
        os.environ[var] = value
raw_ds = load_dataset("zjunlp/KnowEdit")
raw_ds.save_to_disk("./data/KnowEdit")
