import subprocess
import os
result = subprocess.run('bash -c "source /etc/network_turbo && env | grep proxy"', shell=True, capture_output=True, text=True)
output = result.stdout
for line in output.splitlines():
    if '=' in line:
        var, value = line.split('=', 1)
        os.environ[var] = value
import os,sys
os.chdir("/root/EasyEdit")
sys.path.append(os.getcwd())
from easyeditor import BaseEditor
from easyeditor import MEMITHyperParams
import os

#新三元组
hparams=MEMITHyperParams.from_hparams('./hparams/MEMIT/gpt2-xl.yaml')
prompts = ['Ray Charles, the',
            'Grant Hill is a professional',
            'The law in Ikaalinen declares the language'
            ]
ground_truth = ['piano',
                'basketball',
                'Finnish'
                ]
target_new = ['violin',
              'soccer',
              'Swedish'
              ]
subject = ['Ray Charles',
            'Grant Hill',
            'Ikaalinen'
            ]
editor=BaseEditor.from_hparams(hparams)
#改变模型参数
metrics, edited_model_false, _ = editor.edit(
    prompts=prompts,
    ground_truth=ground_truth,
    target_new=target_new,
    subject=subject,
    keep_original_weight=False
)
print(metrics)

"""
python run_knowedit_llama2.py \
    --editing_method=MEMIT \
    --hparams_dir=./hparams/MEMIT/gpt2-xl.yaml \
    --data_dir="./data/KnowEdit/benchmark_wiki_counterfact_train_cf.json" \
    --datatype='counterfact'
"""


