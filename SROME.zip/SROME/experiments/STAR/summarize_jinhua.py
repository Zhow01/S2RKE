import collections
import json
from pprint import pprint
from typing import List, Optional
import numpy as np
import os,sys
os.chdir("/root/EasyEdit")
sys.path.append(os.getcwd())
import numpy as np
from scipy.stats import hmean
from tqdm import tqdm
from easyeditor.util.globals import *
import glob
def search_json_files(directory, pattern):
    matching_files = []
    search_pattern = os.path.join(directory, pattern)
    
    for file_path in glob.glob(search_pattern):
        file_name = file_path.split("/")[-1]
        matching_files.append((file_name,file_name.split("_")[2],file_name.split("_")[3]))
    sorted_data = sorted(matching_files, key=lambda x: (x[2],x[1]))
    return sorted_data

def main(
    dir_name,
    model_name,
    runs: Optional[List],
    first_n_cases=None,
    get_uncompressed=False,
    abs_path=False,
    EDIT_NUM=5,
    kind="star"
):  # runs = None -> all runs
    summaries = []
    uncompressed = []
    ppl = []
    for run_dir in (RESULTS_DIR / dir_name /model_name if not abs_path else dir_name).iterdir():
        # Skip if we're not interested
        if runs is not None and all(run not in str(run_dir) for run in runs):
            continue

        # Iterate through all case files
        cur_sum = collections.defaultdict(lambda: [])
        if(kind=="normal"):
            files = list(run_dir.glob(f"{EDIT_NUM}_edits*.json"))
        elif(kind=="star"):
            files = list(run_dir.glob(f"{EDIT_NUM}_edits*.json"))
        # files.sort(key=lambda x: int(str(x).split("_")[-1].split(".")[0]))
        for case_file in files:
            try:
                with open(case_file, "r") as f:
                    data = json.load(f)
            except json.JSONDecodeError:
                print(f"Could not decode {case_file} due to format error; skipping.")
            pre_ppl,post_ppl = data["ppl"]["pre"],data["ppl"]["post"]
            ppl.append([pre_ppl,post_ppl])
            case_id = data["case_id"]
            if first_n_cases is not None and case_id >= first_n_cases:
                break

            if "time" in data:
                cur_sum["time"].append(data["time"])

            for prefix in ["pre", "post"]:
                # Probability metrics for which new should be lower (better) than true
                for key in ["rewrite_prompts_probs"]:
                    if prefix not in data or key not in data[prefix]:
                        continue

                    sum_key_discrete = f"{prefix}_{key.split('_')[0]}_success"
                    sum_key_cont = f"{prefix}_{key.split('_')[0]}_diff"

                    cur_sum[sum_key_discrete].append(
                        np.mean(
                            [
                                x["target_true"] < x["target_new"]
                                for x in data[prefix][key]
                            ]
                        )
                    )
                    cur_sum[sum_key_cont].append(
                        np.mean(
                            [
                                np.exp(-x["target_new"]) - np.exp(-x["target_true"])
                                for x in data[prefix][key]
                            ]
                        )
                    )

                # Probability metrics for which true should be lower (better) than new
        
                for key in ["rewrite"]:
                    sum_key = f"{prefix}_{key}_acc"
                    key = f"{key}_prompts_correct"

                    if prefix not in data or key not in data[prefix]:
                        continue

                    cur_sum[sum_key].append(np.mean(data[prefix][key]))

                # Ge

        if len(cur_sum) == 0:
            continue

        num_items = len(cur_sum[next(iter(cur_sum.keys()))])
        metadata = {
            "run_dir": str(run_dir),
            "num_cases": num_items,
        }

        uncompressed.append(dict(cur_sum, **metadata))

        cur_sum = {k: (np.mean(v), np.std(v)) for k, v in cur_sum.items()}
        for k, v in cur_sum.items():
            if all(exclude not in k for exclude in ["essence_score", "time"]):
                # Constant multiplication scales linearly with mean and stddev
                cur_sum[k] = tuple(np.around(z * 100, 2) for z in v)

        for prefix in ["pre", "post"]:
            for k_efficacy in [
                (
                    f"{prefix}_rewrite_success",
                ),
                (
                    f"{prefix}_rewrite_acc",
                ),
            ]:
                if all(k in cur_sum for k in [k_efficacy,]):
                    hmean_list = [
                        cur_sum[k_efficacy][0],
                    ]

                    # if f"{prefix}_ngram_entropy" in cur_sum:
                    #     hmean_list.append(2 ** (cur_sum[f"{prefix}_ngram_entropy"][0] / 100))
                    # if f"{prefix}_reference_score" in cur_sum:
                    #     hmean_list.append(cur_sum[f"{prefix}_reference_score"][0])

                    cur_sum[f"{prefix}_score"] = (hmean(hmean_list), np.nan)
                    break
        ppl = np.array(ppl)
        cur_sum["mean_ppl"]={"pre":np.mean(ppl,axis=0)[0],"post":np.mean(ppl,axis=0)[1]}
        cur_sum.update(metadata)
        pprint(cur_sum)
        summaries.append(cur_sum)

    return uncompressed if get_uncompressed else summaries


if __name__ == "__main__":
    CONFIG={
    "method":"MEMIT",
    "model":"gpt2-xl",
    "EDIT_NUM":5,
    "KIND":"star"
        }
    directory_path = f'/root/EasyEdit/results/{CONFIG["method"]}/{CONFIG["model"]}'
    config={"dir_name":CONFIG["method"],
            "model_name":CONFIG["model"],
            "runs":"edit_yago_4000_star_run_184",
            "first_n_cases":None
            }
    
    for num in range(1,11):
        CONFIG["EDIT_NUM"]=str(num)
        result = main(
            config["dir_name"],
            config["model_name"],
            None if config["runs"] is None else config["runs"].split(","),
            config["first_n_cases"],
            EDIT_NUM=CONFIG["EDIT_NUM"],
            kind=CONFIG["KIND"]
        )

        with open(os.path.join(directory_path,f"edit_yago_summarize{CONFIG['method']}_{CONFIG['KIND']}_{CONFIG['EDIT_NUM']}_EPOCH=10.json"), 'w', encoding='utf-8') as file:
            json.dump(result, file, ensure_ascii=False, indent=4)
        