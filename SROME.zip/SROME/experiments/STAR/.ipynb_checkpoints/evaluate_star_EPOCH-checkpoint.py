import json
import shutil
from itertools import islice
from time import time
from typing import Tuple, Union
import os,sys
os.chdir("/root/EasyEdit")
sys.path.append(os.getcwd())
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from easyeditor.models.ft import FTHyperParams, apply_ft_to_model

from easyeditor.models.mend import MENDHyperParams, MendRewriteExecutor
from easyeditor.dsets import (
    AttributeSnippets,
    CounterFactDataset,
    MultiCounterFactDataset,
    get_tfidf_vectorizer,
    RelationCounterFactDataset,
    ChangeCounterFactDataset
)
from experiments.py.eval_utils_counterfact import compute_rewrite_quality_counterfact
from experiments.py.eval_utils_zsre import compute_rewrite_quality_zsre
from easyeditor.models.memit import MEMITHyperParams, apply_memit_to_model
from easyeditor.models.rome import ROMEHyperParams, apply_rome_to_model
from easyeditor.models.pmet import PMETHyperParams,apply_pmet_to_model
from easyeditor.util import nethook
from easyeditor.util.globals import *
import torch
import subprocess
import os
from tqdm import tqdm
torch.cuda.empty_cache()
ALG_DICT = {
    "MEMIT": (MEMITHyperParams, apply_memit_to_model),
    "ROME": (ROMEHyperParams, apply_rome_to_model),
    "FT": (FTHyperParams, apply_ft_to_model),
    "MEND": (MENDHyperParams, MendRewriteExecutor().apply_to_model),
    "PMET":(PMETHyperParams,apply_pmet_to_model)
}

DS_DICT = {
    "mcf": (MultiCounterFactDataset, compute_rewrite_quality_counterfact),
    "cf": (CounterFactDataset, compute_rewrite_quality_counterfact),
    "rcf":(RelationCounterFactDataset, compute_rewrite_quality_counterfact),
    "now":(ChangeCounterFactDataset,compute_rewrite_quality_counterfact)
}
def main(
    kind,
    data:str,
    alg_name: str,
    model_name: Union[str, Tuple],
    hparams_fname: str,
    ds_name: str,
    dataset_size_limit: int,
    continue_from_run: str,
    conserve_memory: bool,
    dir_name: str,
    num_edits: int = 1,
    use_cache: bool = False,
    EXPECT_NUM=10,
    END_NUM=100
):
    # Set algorithm-specific variables
    params_class, apply_algo = ALG_DICT[alg_name]

    # Determine run directory
    # Create new dir if not continuing from prev run OR prev run doesn't exist
    class_name = model_name.split("/")[-1]
    # if not os.path.exists(RESULTS_DIR / dir_name /class_name):
    if (
        continue_from_run is None
        or not (run_dir := RESULTS_DIR / dir_name /class_name/ str(continue_from_run)).exists()
    ):
        continue_from_run = None
    if continue_from_run is None:
        alg_dir = RESULTS_DIR / dir_name/class_name
        if alg_dir.exists():
            id_list = [
                int(str(x).split("_")[-1])
                for x in alg_dir.iterdir()
                if str(x).split("_")[-1].isnumeric()
            ]
            run_id = 0 if not id_list else max(id_list) + 1
        else:
            run_id = 0

        run_dir = RESULTS_DIR / dir_name / class_name / f"edit_yago_{dataset_size_limit}_{kind}_run_{str(run_id).zfill(3)}"
        run_dir.mkdir(parents=True, exist_ok=True)
    print(f"Results will be stored at {run_dir}")

    # Get run hyperparameters
    params_path = (
        run_dir / "params.json"
        if continue_from_run is not None
        else HPARAMS_DIR / alg_name / hparams_fname
    )
    hparams = params_class.from_hparams(str(params_path))
    if not (run_dir / "params.json").exists():
        shutil.copyfile(params_path, run_dir / "params.json")
    print(f"Executing {alg_name} with parameters {hparams}")

    # Instantiate vanilla model
    if type(model_name) is str:
        print("Instantiating model")
        model = AutoModelForCausalLM.from_pretrained(model_name).cuda()
        tok = AutoTokenizer.from_pretrained(model_name)
        tok.pad_token = tok.eos_token
    else:
        model, tok = model_name
        model_name = model.config._name_or_path

    # Load data
    if num_edits > 1:
        assert ds_name != "cf", f"{ds_name} does not support multiple edits"

    ds_class, ds_eval_method = DS_DICT[ds_name]
    js_name = data
    
    ds = ds_class(js_name,DATA_DIR, tok=tok, size=dataset_size_limit)

    # Get cache templates
    cache_template = None
    if use_cache:
        cache_template = (
            KV_DIR
            / f"{model_name.replace('/', '_')}_{alg_name}"
            / f"{ds_name}_layer_{{}}_clamp_{{}}_case_{{}}.npz"
        )
        print(f"Will load cache from {cache_template}")

    # Iterate through dataset
    
    for record_allrel in tqdm(ds):
        if(END_NUM<=0):
            return
        # Compute weight changes + record weights that changed
        case_rel_idss = [f"{record_allrel['case_id']}_{relation}" for relation in record_allrel["Star_Topology"].keys()]

        start = time()
        ##核心内容
        ## case_result_template确定定存放结果的文件夹路径
        case_result_template = str(run_dir / "{}_edits-{}.json")
        """rewrite_case是将多重关系数据格式转变，
                {   "case_rel_ids":0_relation_2,
                    "prompt": "{} influenced",
                    "relation": "<influences>",
                    "target_true": {
                        "str": "El-Ouali Mustapha Sayed"
                    },
                    "target_new": {
                        "str": "Jan Lucanus"
                    }
                }
        """
        rewrite_case = [
            {"case_rel_ids": f"{record_allrel['case_id']}_{relation}","subject":record_allrel["subject"],**rewrite["requested_rewrite"]}
            for relation,rewrite in record_allrel["Star_Topology"].items()
                        ]
        ## NUM的设置是以防关系重数比预期的重数少，造成错误

        if(len(rewrite_case))<EXPECT_NUM:
            continue 
        args_conserve_memory = (
            dict(return_orig_weights_device=("cpu" if conserve_memory else "cuda"))
            if conserve_memory
            else dict()
        )
        etc_args = dict(cache_template=cache_template) if any(alg in alg_name for alg in ["ROME", "MEMIT"]) else dict()

        if (alg_name=="ROME"):
            for idx in range(EXPECT_NUM):
                rewrite_case_single = rewrite_case[idx]
                if(idx==0):
                    edited_model, weights_copy = apply_algo(
                        model,
                        tok,
                        rewrite_case_single,
                        hparams,
                        copy=False,
                        return_orig_weights=False,
                        **args_conserve_memory,
                        **etc_args,
                    )
                else:
                    edited_model, weights_copy = apply_algo(
                        edited_model,
                        tok,
                        rewrite_case_single,
                        hparams,
                        copy=False,
                        return_orig_weights=False,
                        **args_conserve_memory,
                        **etc_args,
                    )
        elif (alg_name=="MEMIT"):
            EPOCH=1
            for epoch in range(EPOCH):
                if (epoch == 0):
                    edited_model, weights_copy = apply_algo(
                        model,
                        tok,
                        rewrite_case[:EXPECT_NUM],
                        hparams,
                        copy=False,
                        return_orig_weights=False,
                        **args_conserve_memory,
                        **etc_args,
                    )
                else:
                    edited_model, weights_copy = apply_algo(
                        edited_model,
                        tok,
                        rewrite_case[:EXPECT_NUM],
                        hparams,
                        copy=False,
                        return_orig_weights=False,
                        **args_conserve_memory,
                        **etc_args,
                    )
                    print(f"------------------------epoch={epoch}--------------------")
        exec_time = time() - start
        print("Execution took", exec_time)
        # Evaluate new model
        start = time()
        ##测量所使用的数据格式与编辑时不同，多一个request_rewrite参数
        """
            {   "case_rel_ids":0_relation_2
                    "requested_rewrite": {"prompt": "{} influenced",
                    "relation": "<influences>",
                    "target_true": {
                        "str": "El-Ouali Mustapha Sayed"
                    },
                    "target_new": {
                        "str": "Jan Lucanus"
                    }
                                        }
            }
        """
        rewrite_eval = [
            {"case_rel_ids": f"{record_allrel['case_id']}_{relation}","subject":record_allrel["subject"],**rewrite}
            for relation,rewrite in record_allrel["Star_Topology"].items()
                        ]
        for case in rewrite_eval[:EXPECT_NUM]:
            out_file = Path(case_result_template.format(str(EXPECT_NUM),case["case_rel_ids"]))
            case["requested_rewrite"]["subject"] = case["subject"]
            if out_file.exists():
                print(f"Skipping {out_file}; already exists")
                continue

            ##目前的评价方法只测量ES和EA，生成能力目前不能测量
            metrics = {
                "case_id": case["case_rel_ids"],
                "grouped_case_ids": case_rel_idss,
                "num_edits": EXPECT_NUM,
                "requested_rewrite": case["requested_rewrite"],
                "time": exec_time,
                "post": ds_eval_method(
                    edited_model,
                    tok,
                    case,
                    snips=None,
                    vec=None
                ),
            }
            device = "cuda"
            # out_file=run_dir + "case.json"
            print(out_file)
            with open(out_file, "w") as f:
                json.dump(metrics, f, indent=1)
            END_NUM-=1
            
            if(END_NUM%20==0):
                print(f"&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&{END_NUM}|||||||||||||||||||||||||||||||||||||||||")
        # Restore original weights
        with torch.no_grad():
            for k, v in weights_copy.items():
                nethook.get_parameter(model, k)[...] = v.to("cuda")

        print("Evaluation took", time() - start)


if __name__ == "__main__":

    config={"alg_name":"MEMIT",#["MEMIT", "ROME", "FT", "MEND"]
            "model_name":"/root/autodl-tmp/gpt2-xl",#因为是本地加载所以是个路径 ["gpt2-medium", "gpt2-large", "gpt2-xl", "EleutherAI/gpt-j-6B"]
            "hparams_fname":"gpt2-xl.yaml",
            "ds_name":"now",#["mcf", "cf", "zsre","rcf","now"]
            "continue_from_run":None,# If continuing from previous run, set to run_id. Otherwise, leave as None.
            "dataset_size_limit":4000,# Truncate CounterFact to first n records.
            "conserve_memory":False,# Reduce memory usage during evaluation at the cost of a minor slowdown. Backs up model weights on CPU instead of GPU.
            "num_edits":1,#Number of rewrites to perform simultaneously
            "use_cache":False,#Use cached k/v pairs
            "data":"concat_person_organization",#("all_0_subjects",30,1),("all_1_subjects",60,2),("all_2_subjects",90,3)
            "EXPECT_NUM":2,
            "kind":"star",
            "END_NUM":200
    }
    methods = ["MEMIT"]##添加好编辑方法即可循环使用每种方法进行编辑
    num=0
    for method in methods:

        config["alg_name"] = method
        config["dir_name"] = method
        for expect_num in range(9,10):
            config["EXPECT_NUM"] = expect_num
            main(
                kind = config["kind"],
                data = config["data"],
                alg_name = config["alg_name"],
                model_name = config["model_name"],
                hparams_fname = config["hparams_fname"],
                ds_name = config["ds_name"],
                dataset_size_limit = config["dataset_size_limit"],
                continue_from_run = config["continue_from_run"],
                conserve_memory = config["conserve_memory"],
                dir_name=config["dir_name"],
                num_edits=config["num_edits"],
                use_cache=config["use_cache"],
                EXPECT_NUM=config["EXPECT_NUM"],
                END_NUM=config["END_NUM"]
                )


